(function(){$("#J_facet_box").find("div[id^=J_itembox_]").each(function(){var a=$(this);var c=a.next(".more-opt");var b=a.children("ul").height();c.data("boxheight",b);if(b>30){c.show()}})})();
