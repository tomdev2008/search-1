_BFD = window["_BFD"]||{};
_BFD.script = document.createElement("script");
_BFD.script.setAttribute("src", "http://www.xiustatic.com/static/js/thirdparty/bfd/zx_list_search.min.js");
_BFD.script.setAttribute('type', 'text/javascript');
_BFD.script.setAttribute("charset", "utf-8");
document.getElementsByTagName("head")[0].appendChild(_BFD.script);